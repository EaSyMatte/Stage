var vetEmail = ["matteo@gmail.com"];
var vetPass = ["Password"];
var vetServizi = ["Pulizie vetri condominio", "Pulizie scale condominio", "Pulizie interni condominio", "Pulizie complete condominio"];
//var listino;

/*function btnCarica() {
    $.ajax({
        url: 'https://raw.githubusercontent.com/EaSyMatte/Stage/main/EmailPassword.json',
        success: function(data) {
            btnLogin(data);
        }
    });
}*/

function btnLogin(){
    $.ajax({
        url: 'https://raw.githubusercontent.com/EaSyMatte/Stage/main/EmailPassword.json',
        success: function(data) {
            var listino = JSON.parse(data);
        }
    });
    let t="";
    t+="<tr><td>"+"<label>Email:</label> "+"</td>";
    t+="<td>"+"<input type='text' id='txtEmail'>"+"</td></tr>";
    t+="<tr><td>"+"<label>Password:</label> "+"<td>";
    t+="<td>"+"<input type='text' id='txtPass'>"+"</td></tr>";

    t+="<tr><td>"+"<button onclick='btnAccedi()'>ACCEDI"+"</td>";
    t+="<td>"+"<button onclick='btnRegistrati()'>REGISTRATI"+"</td></tr>";

    document.getElementById("tableLogin").innerHTML = t;
}

function btnAccedi(){

    let email = document.getElementById("txtEmail").value;
    let pass = document.getElementById("txtPass").value;
    let sentEmail = false;
    let sentPass = false;

    for(let i=0; i<vetEmail.length; i++){
        if(vetEmail[i] == email){
           sentEmail = true;
        }
    }
    for(let i=0; i<vetPass.length; i++){    
        if(vetPass[i] == pass){
            sentPass = true;
        }
    }
    if(sentEmail == false)
        window.alert("Email sbagliata");
    if(sentPass == false)
        window.alert("Password sbagliata");

}

function btnRegistrati(){
    let email = document.getElementById("txtEmail").innerHTML;
    let pass = document.getElementById("txtPass").innerHTML;
    
    let i = vetEmail.length;
    vetEmail[i] = email;
    vetPass[i] = pass;
}

function btnOrdine(i){
    for(let j=0; j<vetServizi.length; j++){
        if(vetServizi[j] == i){
            window.alert("Hai scelto" + vetServizi[j]);
        }
    }
}

function btnConferma(){
    let superficie="";
    let preventivi="";
    let citta = document.getElementById("txtCitta").value;

    if(document.getElementById("rd25").checked == true)
        superficie = document.getElementById("rd25").value;
    else if(document.getElementById("rd50").checked == true)
        superficie = document.getElementById("rd50").value;
    else if(document.getElementById("rd75").checked == true)
        superficie = document.getElementById("rd75").value;
    else 
        superficie = document.getElementById("rd100").value;

    if(document.getElementById("rdSi").checked == true)
        preventivi = document.getElementById("rdSi").value;
    else
        preventivi = document.getElementById("rdNo").value;

    
}

/*function btnAnnulla(){

}*/