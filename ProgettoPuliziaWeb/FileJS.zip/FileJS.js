var vetEmail = ["matteo@gmail.com"];
var vetPass = ["Password1"];

/*function btnCarica() {
    $.ajax({
        url: 'https://raw.githubusercontent.com/EaSyMatte/Stage/main/EmailPassword.json',
        success: function(data) {
            var json = JSON.parse();
        }
    });
}*/

function btnLogin(){
    let t="";
    t+="<tr><td>"+"<label>Email:</label> "+"</td>";
    t+="<td>"+"<input type='text' id='txtEmail'>"+"</td></tr>";
    t+="<tr><td>"+"<label>Password:</label> "+"<td>";
    t+="<td>"+"<input type='text' id='txtPass'>"+"</td></tr>";

    t+="<tr><td>"+"<button onclick='btnAccedi()'>ACCEDI"+"</td>";
    t+="<td>"+"<button onclick='btnRegistrati()'>REGISTRATI"+"</td></tr>";

    document.getElementById("tableLogin").innerHTML = t;
}

function btnAccedi(){
    let email = document.getElementById("txtEmail").value;
    let pass = document.getElementById("txtPass").value;
    let sentEmail = false;
    let sentPass = false;

    for(let i=0; i<vetEmail.length; i++){
        if(vetEmail[i] == email){
           sentEmail = true;
        }
    }
    for(let i=0; i<vetPass.length; i++){    
        if(vetPass[i] == pass){
            sentPass = true;
        }
    }
    if(sentEmail == false)
        window.alert("Email sbagliata");
    if(sentPass == false)
        window.alert("Password sbagliata");

    //btnLoadHomePage();
}

function btnRegistrati(){
    let email = document.getElementById("txtEmail").innerHTML;
    let pass = document.getElementById("txtPass").innerHTML;
    
    let i = vetEmail.length;
    vetEmail[i] = email;
    vetPass[i] = pass;
}


/*function btnLoadHomePage(){
    let s="";
    s+="<tr><td>"+"Pulizie vetri condominio"+"</td>";
    s+="<td>"+"<button onclick='btnOdine()' id='btnOrdine'" + i + ">"+"</td></tr>";

    document.getElementById("tbHomePage") = s;
}*/

/*function btnConferma(){
    
}*/
